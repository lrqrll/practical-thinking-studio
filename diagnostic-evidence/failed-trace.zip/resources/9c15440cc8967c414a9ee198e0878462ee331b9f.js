'use strict';
const BRAND=Object.freeze({name:'NEXUS',version:'3.7.0-rc.1'});
const DEPLOYMENT=Object.freeze(typeof window!=='undefined'&&window.NEXUS_DEPLOYMENT||{channel:'production',commit:null});
const IS_PREVIEW=DEPLOYMENT.channel==='preview'||(typeof location!=='undefined'&&location.pathname.includes('/practical-thinking-studio-preview/'));
const PREVIEW_NAMESPACE=typeof DEPLOYMENT.namespace==='string'&&/^[a-z0-9-]{1,60}$/.test(DEPLOYMENT.namespace)?DEPLOYMENT.namespace:'m31-assembly';
const DATABASE_NAME=IS_PREVIEW?'nexus-preview-'+PREVIEW_NAMESPACE+'-workspace':'nexus-workspace';
const RECOVERY_PREFIX=IS_PREVIEW?'nexus-preview-'+PREVIEW_NAMESPACE+'-recovery:':'nexus-recovery:';
const NexusStore=(()=>{let db;const clone=x=>structuredClone(x);const uid=()=>crypto.randomUUID();const stamp=()=>new Date().toISOString();
function request(r){return new Promise((ok,no)=>{r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error);});}
function complete(tx){return new Promise((ok,no)=>{tx.oncomplete=()=>ok();tx.onabort=tx.onerror=()=>no(tx.error||Error('儲存交易未完成'));});}
async function open(){
 if(!window.indexedDB)throw Error('此瀏覽器不支援 IndexedDB，工作空間無法啟用。');
 db=await new Promise((ok,no)=>{let blocked=false;const r=indexedDB.open(DATABASE_NAME,2);
  r.onupgradeneeded=()=>{for(const name of ['files','folders','meta'])if(!r.result.objectStoreNames.contains(name))r.result.createObjectStore(name,{keyPath:'id'});};
  r.onsuccess=()=>{if(blocked){r.result.close();return;}ok(r.result);};r.onerror=()=>no(r.error);
  r.onblocked=()=>{blocked=true;no(Error('工作空間版本更新被舊分頁阻擋；請先保留輸入、關閉其他 NEXUS 分頁後重試。原資料未清除。'));};
 });db.onversionchange=()=>{db.close();window.dispatchEvent(new Event('nexus-database-versionchange'));};return db;
}
async function readAll(store){return request(db.transaction(store).objectStore(store).getAll());}
async function get(store,id){return request(db.transaction(store).objectStore(store).get(id));}
async function write(store,item){const tx=db.transaction(store,'readwrite'),done=complete(tx);tx.objectStore(store).put(clone(item));await done;return item;}
function validData(type,d){if(!d||typeof d!=='object'||Array.isArray(d))return false;if(type==='time-records')return Object.keys(d).length===1&&NexusTime.valid(d.timeRecords);if(type==='document')return validDocument(d.document);if(type==='notes')return validNote(d.note);if(type==='asset')return validAsset(d.asset);if(type==='budget')return d.budget&&['fixed','price','variable','people'].every(k=>Number.isFinite(d.budget[k])&&d.budget[k]>=0)&&Number.isInteger(d.budget.people)&&Array.isArray(d.budget.rows)&&d.budget.rows.every(r=>Array.isArray(r)&&typeof r[0]==='string'&&Number.isFinite(r[1])&&r[1]>=0);if(type==='tasks')return Array.isArray(d.tasks)&&d.tasks.every(t=>t&&['name','owner','due','depends','status'].every(k=>typeof t[k]==='string'));return ['report','quotes','slides','minutes'].includes(type)&&d.drafts&&typeof d.drafts==='object'&&!Array.isArray(d.drafts)&&Object.values(d.drafts).every(x=>typeof x==='string');}
function record(type,name,data,folderId=null){if(!validData(type,data))throw Error('檔案內容格式不符');const now=stamp();return {id:uid(),type,name:name.trim().slice(0,180)||'未命名',folderId,projectId:null,createdAt:now,updatedAt:now,deletedAt:null,openedAt:now,schemaVersion:1,rev:1,attachments:[],data:clone(data)};}
async function create(type,name,data,folderId){return write('files',record(type,name,data,folderId));}
async function update(id,expected,change){const tx=db.transaction(['files','meta'],'readwrite'),done=complete(tx);const store=tx.objectStore('files');let result;try{const old=await request(store.get(id));if(!old||old.deletedAt)throw Error('檔案已刪除或不存在，請下載目前內容備份。');if(old.rev!==expected)throw Error('這份檔案已在其他分頁更新。請先匯出未保存內容，再重新開啟。');result={...old,...clone(change),id:old.id,type:old.type,rev:old.rev+1,updatedAt:stamp()};if(!validData(result.type,result.data))throw Error('資料格式不符，未寫入');const meta=tx.objectStore('meta'),history=await request(meta.get('history:'+id))||{id:'history:'+id,versions:[]};history.versions.push({rev:old.rev,name:old.name,data:old.data,at:old.updatedAt});history.versions=history.versions.slice(-10);meta.put(history);store.put(result);}catch(e){tx.abort();await done.catch(()=>{});throw e;}await done;return result;}
async function touch(id){const tx=db.transaction('files','readwrite'),done=complete(tx),store=tx.objectStore('files');const f=await request(store.get(id));if(f){f.openedAt=stamp();store.put(f);}await done;return f;}
async function removeEmptyFolder(id){const tx=db.transaction(['files','folders'],'readwrite'),done=complete(tx);const all=await request(tx.objectStore('files').getAll());if(all.some(f=>f.folderId===id)){tx.abort();await done.catch(()=>{});throw Error('資料夾仍有檔案');}const folder=await request(tx.objectStore('folders').get(id));if(folder)tx.objectStore('folders').put({...folder,deletedAt:stamp()});await done;}
async function batchFiles(records){const tx=db.transaction('files','readwrite'),done=complete(tx);for(const item of records)tx.objectStore('files').put(clone(item));await done;}
async function mutateSelection(ids,action,folderId=null){const tx=db.transaction(['files','meta'],'readwrite'),done=complete(tx),store=tx.objectStore('files');if(action==='purge'){try{await assertUnreferenced(tx.objectStore('meta'),ids);}catch(error){tx.abort();await done.catch(()=>{});throw error;}}for(const id of ids){const item=await request(store.get(id));if(!item)continue;if(action==='purge'){if(item.deletedAt){store.delete(id);tx.objectStore('meta').delete('history:'+id);}}else{if(action==='delete')item.deletedAt=stamp();if(action==='restore')item.deletedAt=null;if(action==='move')item.folderId=folderId;item.rev++;item.updatedAt=stamp();store.put(item);}}await done;}
async function emptyTrash(){const tx=db.transaction(['files','folders','meta'],'readwrite'),done=complete(tx);try{const trash=(await request(tx.objectStore('files').getAll())).filter(f=>f.deletedAt).map(f=>f.id);await assertUnreferenced(tx.objectStore('meta'),trash);}catch(error){tx.abort();await done.catch(()=>{});throw error;}for(const name of ['files','folders']){const store=tx.objectStore(name);for(const item of await request(store.getAll()))if(item.deletedAt){store.delete(item.id);if(name==='files')tx.objectStore('meta').delete('history:'+item.id);}}await done;}
async function editToolPrefs(action,id){const tx=db.transaction('meta','readwrite'),done=complete(tx),store=tx.objectStore('meta');const prefs=await request(store.get('tool-preferences'))||{id:'tool-preferences',favorites:[],recent:[]};if(action==='favorite')prefs.favorites=prefs.favorites.includes(id)?prefs.favorites.filter(x=>x!==id):[...prefs.favorites,id];if(action==='recent')prefs.recent=[{id,at:stamp()},...prefs.recent.filter(x=>x.id!==id)].slice(0,8);store.put(prefs);await done;return prefs;}
const workbenchKey=id=>typeof id==='string'&&id.startsWith('workbench:');
const snapshotKey=id=>typeof id==='string'&&id.startsWith('workbench-snapshot:');
function metaRange(prefix){return IDBKeyRange.bound(prefix,prefix+'\uffff');}
async function readMetaPrefix(prefix){if(!['workbench:','workbench-snapshot:','workbench-template:','workbench-layout:'].includes(prefix))throw Error('不支援的資料範圍');return request(db.transaction('meta').objectStore('meta').getAll(metaRange(prefix)));}
async function workbenchTransaction(action,withFolders=false){
 const tx=db.transaction(withFolders?['files','folders','meta']:['files','meta'],'readwrite'),done=complete(tx);done.catch(()=>{});
 try{const result=await action(tx.objectStore('files'),tx.objectStore('meta'));await done;return result;}
 catch(error){try{tx.abort();}catch{}await done.catch(()=>{});throw error;}
}
function requireWorkbench(w,expected){if(!NexusWorkbench.valid(w))throw Error('工作台不存在或格式不符');if(w.rev!==expected)throw Error('工作台已在其他分頁更新，請重新讀取；未覆寫新版本');}
async function createWorkbench(name){return workbenchTransaction(async(_files,meta)=>{const count=await request(meta.count(metaRange('workbench:')));if(count>=100)throw Error('工作台上限100，請先備份管理');const at=stamp(),w={id:'workbench:'+uid(),schemaVersion:1,rev:1,name:name.trim(),createdAt:at,updatedAt:at,deletedAt:null,modules:[]};if(!NexusWorkbench.valid(w))throw Error('請填寫180字內工作台名稱');meta.add(w);return clone(w);});}
async function createCategorizedWorkbench(name){return workbenchTransaction(async(_files,meta)=>{
 const count=await request(meta.count(metaRange('workbench:')));if(count>=100)throw Error('工作台上限100，請先備份管理');
 const at=stamp(),w={id:'workbench:'+uid(),schemaVersion:1,rev:1,name:typeof name==='string'?name.trim():'',createdAt:at,updatedAt:at,deletedAt:null,modules:[]};
 if(!NexusWorkbench.valid(w))throw Error('請填寫180字內工作台名稱');const layout=NexusCategories.create(w.id,at);meta.add(w);meta.add(layout);return {workbench:clone(w),layout:clone(layout)};
});}
async function editCategories(workbenchId,expected,operation,payload){return workbenchTransaction(async(files,meta)=>{
 const w=await request(meta.get(workbenchId));if(!NexusWorkbench.valid(w)||w.deletedAt)throw Error('工作台不存在或在垃圾桶');
 const current=await request(meta.get(NexusCategories.key(workbenchId)));if(!NexusCategories.valid(current))throw Error('分類配置未知，請完整備份；未改寫');if(current.rev!==expected)throw Error('分類已在其他分頁更新；保留您的輸入，請重新讀取後重試');
 let file=null,parameters=clone(payload);
 if(operation==='add-item'){
  if(await request(files.count())>=5000)throw Error('檔案已達完整備份支援上限5000；未建立半份內容，請先完整備份及整理');
  if(!NexusCategories.kinds.includes(payload.toolType))throw Error('工具尚未完成或不支援');
  file=record(payload.toolType,payload.name,blankData(payload.toolType));parameters.fileId=file.id;
 }
 const layout=NexusCategories.change(current,operation,parameters,{uid,now:stamp});if(file)files.add(file);meta.put(layout);return {layout:clone(layout),file:clone(file)};
});}
async function updateWorkbench(id,expected,change){return workbenchTransaction(async(files,meta)=>{
 const old=await request(meta.get(id));requireWorkbench(old,expected);
 const w={...old,name:change.name===undefined?old.name:change.name.trim(),modules:change.modules===undefined?old.modules:clone(change.modules),deletedAt:change.deletedAt===undefined?old.deletedAt:change.deletedAt,rev:old.rev+1,updatedAt:stamp()};
 if(!NexusWorkbench.valid(w))throw Error('工作台設定不符，未保存');
 for(const m of w.modules)if(!old.modules.some(x=>x.kind===m.kind&&x.sourceId===m.sourceId)){const f=await request(files.get(m.sourceId));if(!f||f.deletedAt||f.type!==m.kind)throw Error('來源不存在、型別不符或在垃圾桶');}
 meta.put(w);return clone(w);
 });}
async function createWorkbenchSource(id,expected,kind){return workbenchTransaction(async(files,meta)=>{
 const old=await request(meta.get(id));requireWorkbench(old,expected);if(old.deletedAt||!NexusWorkbench.kinds.includes(kind))throw Error('無法建立來源');
 const file=record(kind,old.name+(kind==='quotes'?' 報價比較':' 決策備忘'),blankData(kind));
 const w={...old,modules:[...old.modules.filter(m=>m.kind!==kind),{id:old.modules.find(m=>m.kind===kind)?.id||uid(),kind,sourceId:file.id}],rev:old.rev+1,updatedAt:stamp()};if(!NexusWorkbench.valid(w))throw Error('工作台格式不符');files.add(file);meta.put(w);return {workbench:clone(w),file:clone(file)};
 });}
async function createWorkbenchSnapshot(id,expected){return workbenchTransaction(async(files,meta)=>{
 const w=await request(meta.get(id));requireWorkbench(w,expected);const count=await request(meta.count(metaRange('workbench-snapshot:')));if(count>=200)throw Error('固定成果上限200，請先備份；未覆寫既有成果');
 const sources=[];for(const m of w.modules){const f=await request(files.get(m.sourceId));if(f&&!validData(f.type,f.data))throw Error('來源資料格式不符');sources.push(f);}
 const s=NexusWorkbench.makeSnapshot(w,sources.filter(Boolean),'workbench-snapshot:'+uid(),stamp());meta.add(s);return clone(s);
 });}
async function purgeWorkbench(id,expected){return workbenchTransaction(async(_files,meta)=>{const w=await request(meta.get(id));requireWorkbench(w,expected);if(!w.deletedAt)throw Error('請先將工作台移至垃圾桶');for(const s of await request(meta.getAll(metaRange('workbench-snapshot:'))))if(s.workbenchId===w.id)meta.delete(s.id);meta.delete(NexusCategories.key(w.id));meta.delete(w.id);});}
async function assertUnreferenced(meta,ids){const set=new Set(ids);if(!set.size)return;
 const refs=(await request(meta.getAll(metaRange('workbench:')))).filter(w=>Array.isArray(w.modules)&&w.modules.some(m=>set.has(m.sourceId)));
 const layouts=await request(meta.getAll(metaRange('workbench-layout:')));
 if(layouts.some(l=>!NexusCategories.valid(l)))throw Error('有未知分類配置，請完整備份並更新程式；未永久刪除任何檔案');
 const linked=layouts.filter(l=>l.items.some(i=>set.has(i.fileId)));
 if(refs.length||linked.length)throw Error('來源仍被工作台引用（含垃圾桶工作台），請先保留完整備份；未永久刪除');
}

async function editWorkbenchFields(id,expected,operation,payload){return workbenchTransaction(async(_files,meta)=>{const old=await request(meta.get(id));requireWorkbench(old,expected);if(old.deletedAt)throw Error('請先還原工作台');const w={...NexusFields.change(old,operation,payload,{uid,now:stamp()}),rev:old.rev+1,updatedAt:stamp()};if(!NexusWorkbench.valid(w))throw Error('欄位設定不符');meta.put(w);return clone(w);});}
async function createWorkbenchTemplate(id,expected,name){return workbenchTransaction(async(_files,meta)=>{const w=await request(meta.get(id));requireWorkbench(w,expected);if(w.deletedAt)throw Error('請先還原工作台');if(await request(meta.count(metaRange('workbench-template:')))>=100)throw Error('範本上限100（含垃圾桶），請先完整備份');const t=NexusFields.makeTemplate(w,name,{uid,now:stamp()});meta.add(t);return clone(t);});}
async function saveWorkbenchTemplate(id,expected,change){return workbenchTransaction(async(_files,meta)=>{
 const old=await request(meta.get(id));if(!NexusFields.validTemplate(old))throw Error('範本不存在或不支援');if(old.rev!==expected)throw Error('範本已在其他分頁更新，請保留草稿再重新讀取');
 if(old.deletedAt&&change.deletedAt!==null)throw Error('請先還原範本');
 let fields=change.fields===undefined?old.fields:clone(change.fields);if(!Array.isArray(fields)||old.fields.some(f=>!fields.some(x=>x?.id===f.id)))throw Error('範本欄位只能可恢復移除，不可清除定義');
 fields=fields.map(f=>{const previous=old.fields.find(x=>x.id===f?.id);if(!previous)return f;if(f.type!==previous.type||JSON.stringify(f.options)!==JSON.stringify(previous.options))throw Error('欄位型別與選項固定，請新增欄位');return {...previous,label:f.label,deletedAt:f.deletedAt};});
 const defaults=change.defaults===undefined?old.defaults:{...old.defaults,...clone(change.defaults)};
 const t={...old,name:change.name===undefined?old.name:change.name.trim(),fields,defaults,deletedAt:change.deletedAt===undefined?old.deletedAt:change.deletedAt,rev:old.rev+1,updatedAt:stamp()};
 for(const f of old.fields)if(!f.deletedAt&&fields.find(x=>x.id===f.id)?.deletedAt&&Object.hasOwn(old.defaults,f.id)&&old.defaults[f.id]!==null&&old.defaults[f.id]!==''&&!change.confirmed)throw Error('移除含預設值欄位需要確認');
 if(!NexusFields.validTemplate(t))throw Error('範本或預設值無效，原資料未變更');meta.put(t);return clone(t);
 });}
async function createWorkbenchFromTemplate(id,expected,name){return workbenchTransaction(async(_files,meta)=>{const t=await request(meta.get(id));if(!NexusFields.validTemplate(t)||t.rev!==expected)throw Error('範本版本已變更或不支援，請重新讀取');if(await request(meta.count(metaRange('workbench:')))>=100)throw Error('工作台上限100');const w=NexusFields.instantiate(t,name,{uid,now:stamp()});if(!NexusWorkbench.valid(w))throw Error('工作台名稱或範本不符');meta.add(w);return clone(w);});}
async function createM2Recovery(kind,data,name){return workbenchTransaction(async(_files,meta)=>{const prefix=kind==='workbench'?'workbench:':kind==='template'?'workbench-template:':null;if(!prefix)throw Error('草稿種類不符');if(await request(meta.count(metaRange(prefix)))>=100)throw Error('復原副本超過數量上限，草稿仍保留');if(kind==='workbench'?(data?.schemaVersion!==2||!NexusFields.validState(data)):!NexusFields.validTemplate(data))throw Error('草稿仍有錯誤，請先修正；未覆寫任何資料');const copied=NexusFields.remapState(data,NexusFields.mapper(uid),kind==='workbench'?'values':'defaults'),now=stamp();Object.assign(copied,{id:prefix+uid(),name:name.trim(),rev:1,createdAt:now,updatedAt:now,deletedAt:null});if(kind==='workbench')copied.modules=[];if(kind==='workbench'?!NexusWorkbench.valid(copied):!NexusFields.validTemplate(copied))throw Error('草稿副本格式不符');meta.add(copied);return clone(copied);});}
async function readAssemblySources(refs){
 if(!Array.isArray(refs)||!refs.length||refs.length>80||refs.some(r=>!r||!['notes','snapshot'].includes(r.kind)||typeof r.id!=='string'))throw Error('來源選擇不符');
 const tx=db.transaction(['files','meta'],'readonly'),done=complete(tx);done.catch(()=>{});
 try{const values=await Promise.all(refs.map(r=>request(tx.objectStore(r.kind==='notes'?'files':'meta').get(r.id))));
 const parents=await Promise.all(values.map((v,i)=>refs[i].kind==='snapshot'&&v?request(tx.objectStore('meta').get(v.workbenchId)):Promise.resolve(null)));
 await done;return values.map((record,i)=>{const r=refs[i];if(!record||record.deletedAt||r.kind==='snapshot'&&(!parents[i]||parents[i].deletedAt))throw Error('來源已失效或移至垃圾桶，請重新選擇');if((r.kind==='notes'?record.rev:record.workbenchRev)!==r.rev)throw Error('來源已在其他畫面更新，請重新選擇已保存版本');if(r.kind==='notes'&&!validData('notes',record.data))throw Error('備忘錄格式不符，請重新選擇');NexusAssembly.validate(r.kind,record);return{kind:r.kind,record:clone(record)};});
 }catch(e){try{tx.abort();}catch{}await done.catch(()=>{});throw e;}
}
async function snapshot(){const tx=db.transaction(['files','folders','meta'],'readonly'),done=complete(tx);done.catch(()=>{});const [files,folders,meta]=await Promise.all(['files','folders','meta'].map(s=>request(tx.objectStore(s).getAll())));await done;
 const workbenches=meta.filter(x=>workbenchKey(x.id)),workbenchSnapshots=meta.filter(x=>snapshotKey(x.id)),workbenchTemplates=meta.filter(x=>x.id.startsWith('workbench-template:')),workbenchLayouts=meta.filter(x=>x.id.startsWith('workbench-layout:')),m2=workbenchLayouts.length||workbenchTemplates.length||workbenches.some(w=>w.schemaVersion===2)||workbenchSnapshots.some(s=>s.schemaVersion===2);
 return {kind:'nexus-workspace',version:workbenchLayouts.length?4:m2?3:workbenches.length||workbenchSnapshots.length?2:1,exportedAt:stamp(),files,folders,archives:meta.filter(x=>x.id.startsWith('archive:')),preferences:meta.find(x=>x.id==='tool-preferences')||null,histories:meta.filter(x=>x.id.startsWith('history:')&&files.some(f=>x.id==='history:'+f.id)),...(m2||workbenches.length||workbenchSnapshots.length?{workbenches,workbenchSnapshots}:{}),...(m2?{workbenchTemplates}:{}),...(workbenchLayouts.length?{workbenchLayouts}:{})};
}
function validateBackupV1(x){const ids=new Set();if(!x||x.kind!=='nexus-workspace'||x.version!==1||!Array.isArray(x.files)||x.files.length>5000||!Array.isArray(x.folders)||!Array.isArray(x.archives))return false;if(x.preferences&&(!Array.isArray(x.preferences.favorites)||x.preferences.favorites.some(v=>typeof v!=='string')||!Array.isArray(x.preferences.recent)||x.preferences.recent.some(v=>!v||typeof v.id!=='string'||typeof v.at!=='string')))return false;if(x.folders.some(f=>!f||typeof f.id!=='string')||x.archives.some(a=>!a))return false;if(x.histories&&(!Array.isArray(x.histories)||x.histories.some(h=>!h||typeof h.id!=='string'||!Array.isArray(h.versions)||h.versions.length>10||!h.versions.every(v=>{const f=x.files.find(f=>f&&h.id==='history:'+f.id);return f&&v&&typeof v.name==='string'&&typeof v.at==='string'&&Number.isSafeInteger(v.rev)&&v.rev>0&&v.rev<Number.MAX_SAFE_INTEGER&&validData(f.type,v.data);}))))return false;const folders=new Set(x.folders.map(f=>f.id));if(folders.size!==x.folders.length)return false;return x.folders.every(f=>f&&typeof f.id==='string'&&typeof f.name==='string'&&f.name.length<=180)&&x.archives.every(a=>a&&typeof a.raw==='string')&&x.files.every(f=>{if(!f||typeof f.id!=='string'||ids.has(f.id)||typeof f.name!=='string'||f.name.length>180||!validData(f.type,f.data)||f.folderId!==null&&!folders.has(f.folderId))return false;ids.add(f.id);return true;});}
function validateBackup(x){
 if(x?.version===4){
  if(!Array.isArray(x.workbenchLayouts)||!x.workbenchLayouts.length||x.workbenchLayouts.length>100||!validateBackup({...x,version:3,workbenchLayouts:undefined}))return false;
  try{const files=new Map(x.files.map(f=>[f.id,f])),benches=new Set(x.workbenches.map(w=>w.id));return new Set(x.workbenchLayouts.map(l=>l?.id)).size===x.workbenchLayouts.length&&new Set(x.workbenchLayouts.flatMap(l=>l?.items?.map(i=>i.fileId)||[])).size===x.workbenchLayouts.reduce((n,l)=>n+(l.items?.length||0),0)&&x.workbenchLayouts.every(l=>NexusCategories.valid(l)&&benches.has(l.workbenchId)&&l.items.every(i=>files.get(i.fileId)?.type===i.toolType));}catch{return false;}
 }
 if(x?.workbenchLayouts!==undefined)return false;
 if(x?.version===1)return !x.workbenches&&!x.workbenchSnapshots&&!x.workbenchTemplates&&validateBackupV1(x);
 if(![2,3].includes(x?.version)||!validateBackupV1({...x,version:1})||!Array.isArray(x.workbenches)||x.workbenches.length>100||!Array.isArray(x.workbenchSnapshots)||x.workbenchSnapshots.length>200)return false;
 if(x.version===2&&(x.workbenchTemplates||x.workbenches.some(w=>w?.schemaVersion!==1)||x.workbenchSnapshots.some(s=>s?.schemaVersion!==1)))return false;
 if(x.version===3&&(!Array.isArray(x.workbenchTemplates)||x.workbenchTemplates.length>100||new Set(x.workbenchTemplates.map(t=>t?.id)).size!==x.workbenchTemplates.length||!x.workbenchTemplates.every(NexusFields.validTemplate)))return false;
 try{const files=new Map(x.files.map(f=>[f.id,f])),workbenches=new Map(x.workbenches.map(w=>[w?.id,w]));return x.files.every(f=>Number.isSafeInteger(f.rev)&&f.rev>0&&f.rev<Number.MAX_SAFE_INTEGER)&&workbenches.size===x.workbenches.length&&new Set(x.workbenches.flatMap(w=>w?.modules?.map(m=>m.id)||[])).size===x.workbenches.reduce((n,w)=>n+(w?.modules?.length||0),0)&&x.workbenches.every(w=>NexusWorkbench.valid(w)&&w.modules.every(m=>files.get(m.sourceId)?.type===m.kind))&&new Set(x.workbenchSnapshots.map(s=>s?.id)).size===x.workbenchSnapshots.length&&x.workbenchSnapshots.every(s=>NexusWorkbench.validSnapshot(s)&&workbenches.has(s.workbenchId)&&(s.schemaVersion!==2||workbenches.get(s.workbenchId).schemaVersion===2&&s.customFields.every(c=>workbenches.get(s.workbenchId).fields.some(f=>f.id===c.field.id&&f.type===c.field.type&&(f.type!=='select'||c.field.options.every(o=>f.options.some(x=>x.id===o.id))))))&&s.workbenchRev<=workbenches.get(s.workbenchId).rev&&s.sourceVersions.every(v=>!files.has(v.fileId)||files.get(v.fileId).type===v.kind&&v.rev<=files.get(v.fileId).rev));}catch{return false;}
}
async function importBackup(x){
 if(!validateBackup(x))throw Error('備份格式不符，原資料未變更');
 return workbenchTransaction(async(files,meta)=>{
  const templateCount=await request(meta.count(metaRange('workbench-template:')));if(templateCount+(x.workbenchTemplates?.length||0)>100)throw Error('範本超過上限，未匯入任何資料');
  const benchCount=await request(meta.count(metaRange('workbench:'))),snapshotCount=await request(meta.count(metaRange('workbench-snapshot:')));if(benchCount+(x.workbenches?.length||0)>100||snapshotCount+(x.workbenchSnapshots?.length||0)>200)throw Error('工作台或成果超過上限，未匯入任何資料');
  const fieldMaps=new Map();const fieldMap=id=>{if(!fieldMaps.has(id))fieldMaps.set(id,NexusFields.mapper(uid));return fieldMaps.get(id);};
  const map=new Map(),fileMap=new Map(),benchMap=new Map(),moduleMap=new Map();const fresh=(m,id)=>{if(!m.has(id))m.set(id,uid());return m.get(id);};
  // One transaction includes legacy files, folders, all linked workbenches and results.
  const folders=meta.transaction.objectStore('folders');
  for(const f of x.folders){const id=fresh(map,f.id);folders.put({id,name:f.name,createdAt:stamp(),deletedAt:f.deletedAt?stamp():null});}
  for(const f of x.files){const item=record(f.type,f.name,f.data,map.get(f.folderId)||null);fileMap.set(f.id,item.id);item.deletedAt=f.deletedAt?stamp():null;const h=x.histories?.find(h=>h.id==='history:'+f.id);if(h){item.rev=Math.max(1,...h.versions.map(v=>v.rev+1));meta.put({id:'history:'+item.id,versions:clone(h.versions)});}if(x.version>=2)item.rev=Math.max(item.rev,f.rev);files.put(item);}
  for(const arc of x.archives)meta.put({id:'archive:'+uid(),raw:arc.raw,createdAt:stamp()});
  if(x.preferences){const p=await request(meta.get('tool-preferences'))||{favorites:[],recent:[]};meta.put({id:'tool-preferences',favorites:[...new Set([...p.favorites,...x.preferences.favorites])],recent:[...p.recent,...x.preferences.recent].filter((v,i,a)=>a.findIndex(y=>y.id===v.id)===i).slice(0,8)});}
  for(const w of x.workbenches||[]){const id='workbench:'+uid();benchMap.set(w.id,id);const copied=w.schemaVersion===2?NexusFields.remapState(w,fieldMap(w.id)):clone(w);meta.add({...copied,id,name:(w.name+' 還原副本').slice(0,180),modules:w.modules.map(m=>({...m,id:fresh(moduleMap,m.id),sourceId:fileMap.get(m.sourceId)}))});}
  for(const s of x.workbenchSnapshots||[]){const imported=clone(s);if(s.schemaVersion===2)imported.customFields=NexusFields.remapCaptured(s.customFields,fieldMap(s.workbenchId));imported.id='workbench-snapshot:'+uid();imported.workbenchId=benchMap.get(s.workbenchId);imported.sourceVersions=imported.sourceVersions.map(v=>({...v,moduleId:fresh(moduleMap,v.moduleId),fileId:fresh(fileMap,v.fileId)}));meta.add(imported);}
  for(const layout of x.workbenchLayouts||[]){const copy=NexusCategories.remap(layout,benchMap.get(layout.workbenchId),fileMap,uid);meta.add(copy);}
  for(const t of x.workbenchTemplates||[]){const copy=NexusFields.remapState(t,NexusFields.mapper(uid),'defaults');copy.id='workbench-template:'+uid();meta.add(copy);}
 },true);
}
async function initialize(legacy,extract,names={}){if(await get('meta','initialized'))return;let imported=[],legacyTheme='light';if(legacy){let parsed;try{parsed=JSON.parse(legacy);}catch{}if(parsed&&parsed.version===1){if(['light','dark'].includes(parsed.theme))legacyTheme=parsed.theme;for(const type of ['budget','tasks','report','quotes','slides','minutes']){const data=extract(type,parsed);if(validData(type,data))imported.push(record(type,(names[type]||type)+'（原工作資料）',data));}}}const tx=db.transaction(['files','meta'],'readwrite'),done=complete(tx);if(await request(tx.objectStore('meta').get('initialized'))){await done;return;}if(legacy)tx.objectStore('meta').put({id:'archive:legacy-v1',raw:legacy,createdAt:stamp()});for(const f of imported)tx.objectStore('files').put(f);tx.objectStore('meta').put({id:'settings',theme:legacyTheme});tx.objectStore('meta').put({id:'initialized',at:stamp()});await done;}
return {createCategorizedWorkbench,editCategories,readAssemblySources,createM2Recovery,editWorkbenchFields,createWorkbenchTemplate,saveWorkbenchTemplate,createWorkbenchFromTemplate,readMetaPrefix,createWorkbench,updateWorkbench,createWorkbenchSource,createWorkbenchSnapshot,purgeWorkbench,emptyTrash,editToolPrefs,touch,removeEmptyFolder,open,readAll,get,write,create,update,batchFiles,mutateSelection,snapshot,validateBackup,importBackup,initialize,uid,stamp,record,validData};})();
