'use strict';
window.NEXUS_DEPLOYMENT=Object.freeze({"channel":"preview","namespace":"m33-categories","commit":"3727e6f39b0114298bffa3278afac9fa95025c0d","version":"3.7.0-rc.1","source":"https://github.com/lrqrll/practical-thinking-studio/tree/3727e6f39b0114298bffa3278afac9fa95025c0d"});
